import logo from "./logo.svg";
import "./App.css";
import Simple from "./component/Simple";
import Ui from "./component/Ui"
function App() {
  return (
    <div className="App">
      {/* <Simple /> */}
      <Ui />
    </div>
  );
}

export default App;
